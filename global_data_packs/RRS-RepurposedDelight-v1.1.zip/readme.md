## Repurposed Delight (v1.0)

Adds the following:

- Compost Pile structures for every village type in ReStruc

Compatibilty:

- Environmental: Switches around the Swamp Compost Pile to use willow wood, cattails and mud. REQUIRES EXTRA DOWNLOAD
